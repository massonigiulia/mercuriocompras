export interface IMenu {
    Numero: number,
    Nome: string,
    SubItem: ISubItem[]
}

export interface ISubItem {
    Numero: number,
    Nome: string
}