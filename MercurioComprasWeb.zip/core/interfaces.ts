import * as React from "react";

export type IMenu = {
    readonly title: string;
    readonly url: string;
    readonly operationId?: number| ReadonlyArray<number>;
} & (
    ({
        readonly hide:true;
        readonly icon?: undefined;
    } |
    {
        readonly hide?:undefined;
        readonly icon?: string;
    }) &
    ({
        readonly items: ReadonlyArray<IMenu>;
        readonly element?: React.ExoticComponent<any> | React.FunctionComponent<any> | React.ComponentClass<any> | React.ComponentClass<any>
    } |
    {
        readonly items?: undefined;
        readonly element: React.ExoticComponent<any> | React.FunctionComponent<any> | React.ComponentClass<any> | React.ComponentClass<any>
    }
    )
);

export interface IModule {
    readonly order: number;
    readonly systemId: number;
    readonly name: string;
    readonly menu: IMenu;
    readonly operationId?: number;
}

export interface IUser {
    readonly Name:string;
    readonly Email:string;
    HasPermission(systemId:number, operationId?:number | ReadonlyArray<number>):boolean;
}