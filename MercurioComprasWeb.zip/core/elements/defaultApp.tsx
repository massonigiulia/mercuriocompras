// import * as React from 'react'
// import { IModule, IUser } from "../interfaces";
// import { Menu } from './menu';
// import "../../style/bds.css"
// import "../../style/awesome-bootstrap-checkbox.css"
// import "../../common/sortable/sortable.ts"
// import "../../common/filterable/filterable.ts"
// import Link from 'next/link';
// // import "glyphicons/"

// interface IDefaultAppProps {
//     modules:Array<IModule>;
//     // user: IUser;
//     // baseUrl: string;
//     version: string;
//     year: number;
// }


// //========================================================================
// // componente principal
// //========================================================================
// export class DefaultApp extends React.PureComponent<IDefaultAppProps> {
 
    
//     render() {        
//         const { version, modules:nomSortedModules, year} = this.props;
//         const modules = [...nomSortedModules].sort((a, b) => {    
//             return (a.order > b.order)? 1: (a.order < b.order)? -1:0;   
//         });
//         return (
//             <Link href={"/"}>
//                 <>
//                     <nav className="navbar-default navbar-static-side" role="navigation" id="defaultNavBar">
//                         <Menu items={modules} />
//                     </nav>

//                     <div id="page-wrapper" className={"gray-bg fadeInDown dashbard-1"}>

//                         <div className="row border-bottom">

//                             <nav className="navbar navbar-static-top" role="navigation" style={{"marginBottom":0}}>

//                                 <div className="navbar-header">

//                                     <a className="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#" onClick={e=> e.preventDefault()}>
//                                         <i className="fa fa-bars" />
//                                     </a>                                  
//                                 </div>
//                                 <br/>
//                                     <ul className="nav navbar-top-links navbar-right">

//                                         <li className="dropdown">                                                                                   
//                                         </li>

//                                         <li>
//                                             <img id="profile-pic" alt="image" className="img-circle" src="res/graphics/profile.jpg" />
//                                         </li>

//                                         <li>
//                                             <span className="m-r-sm text-muted welcome-message">Bem vindo(a)</span>
//                                         </li>
//                                         <li>
//                                             <a href="/logout">Sair</a>
//                                         </li>

//                                     </ul>

//                             </nav>
//                         </div>

//                         <br />

//                         <div className="footer">
//                             <div className="pull-right">
//                                 BDS Licenciamentos e Soluções  LTDA. © {year}                                
//                             </div>
//                             <div>
//                                 BDS.WEB versão <strong>{version}</strong>
//                             </div>
//                         </div>
                        
//                     </div>
//                 </>
//             </Link>

//         );

//     }

// }
