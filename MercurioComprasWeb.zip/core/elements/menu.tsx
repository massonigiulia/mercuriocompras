import * as React from 'react'
import Link from 'next/link';
import { useRouter } from "next/router";
import { IModule, IUser, IMenu } from "../interfaces";


interface IMenuProps {
    readonly items: Array<IModule>;
    readonly user: IUser;
    readonly baseUrl: string;
}

const router = useRouter();

//========================================================================
// menu lateral da esquerda (navegação)
//========================================================================
export const Menu = function Menu({items, user, baseUrl}:IMenuProps) {

    const itens = items && items.filter(m => !m.menu.hide && user.HasPermission(m.systemId)).map((mod, i) => (
        <MenuItem title={mod.menu.title} classe={mod.menu.icon} link={(baseUrl + mod.menu.url)} items={mod.menu.items} key={i} systemId={mod.systemId} user={user} baseUrl={baseUrl} />)
    );

    return (
        <div className="sidebar-collapse">
            <ul className="nav metismenu" id="side-menu">
                <li className="nav-header">
                    <div className="profile-element"><img src="res/graphics/bds.png" alt="logo" id="logo"/></div>
                    <div className="logo-element">BDS</div>
                </li>
                {itens}
            </ul>
        </div>
    );

}

interface IMenuItemProps {
    readonly title: string;
    readonly link: string;
    readonly items?: ReadonlyArray<IMenu>;
    readonly classe?: string;
    readonly systemId: number;
    readonly user: IUser;
    readonly baseUrl: string;
}

//========================================================================
// item de menu (level 1)
//========================================================================
const MenuItem = ({title, link, items, classe, systemId, user, baseUrl}:IMenuItemProps) => {

    const subItems = items && items.filter(i => !i.hide && user.HasPermission(systemId, i.operationId)).map((item, i) => (
        <MenuSubItem title={item.title} classe={item.icon} link={(link || baseUrl) + "/" + item.url} items={item.items} key={i} systemId={systemId} baseUrl={baseUrl} user={user} />
    ));

    if (subItems && subItems.length){

        if (classe){

            return (
                <li>
                    <a href="#">
                        <i className={classe} />
                        <span className="nav-label">{title}</span>
                        <span className="fa arrow" />
                    </a>
                    <ul className="nav nav-second-level collapse">
                        {subItems}
                    </ul>
                </li>
            );

        }

        return (
            <li>
                <a href="#">
                    <span className="nav-label">{title}</span>
                    <span className="fa arrow" />
                </a>
                <ul className="nav nav-second-level collapse">
                    {subItems}
                </ul>
            </li>
        );

    }

    if (classe){

        return (
            <li>
                
                <Link href={link} className={router.pathname == "/" ? "active" : ""}>
                    <i className={classe}/>
                    <span className="nav-label">{title}</span>
                </Link>
            </li>
        );

    }

    return (
        <li>
            <Link href={link} className={router.pathname == "/" ? "active" : ""}>
                <span className="nav-label">{title}</span>
            </Link>
        </li>
    );

}

//========================================================================
// item de menu (level 2)
//========================================================================
const MenuSubItem = ({title, link, items, classe, systemId, user, baseUrl}:IMenuItemProps) => {

    const subItems = items && items.filter(i => !i.hide && user.HasPermission(systemId, i.operationId)).map((item, i) => (
        <MenuSubItem title={item.title} classe={item.icon} link={(link||"") + "/" + item.url} items={item.items} key={i} user={user} baseUrl={baseUrl} systemId={systemId} />
    ));

    if(subItems && subItems.length){
        if(classe){
            return (
                <li>
                    <a href="#" ><i className={classe}></i>{title}<span className="fa arrow"></span></a>
                    <ul className="nav nav-third-level collapse">
                        {subItems}
                    </ul>
                </li>
            );

        }
        

        return (
            <li>
                <a href="#">{title}<span className="fa arrow"></span></a>
                <ul className="nav nav-third-level collapse">
                    {subItems}
                </ul>
            </li>
        );

    }

    if(classe){
        return (
            <li>   
                <Link href={link} className={router.pathname == "/" ? "active" : ""}><i className={classe} />{title}</Link>
            </li>
        );
    }

    return (
        <li>
            <Link href={link} className={router.pathname == "/" ? "active" : ""}></Link>
        </li>
    );

}