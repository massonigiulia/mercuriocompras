import '../styles/globals.css'
import './diretoria/pendentes'
//import 'bootstrap';

function MyApp({ Component, pageProps }) {
  return (
    <>
        <Component {...pageProps} />
    </>
  )


}
export default MyApp
