import { lazy } from "react";
import { IModule } from '../../core/interfaces';

const Template = lazy(() => import('../templateMenu'));

export const Menu: IModule = {
    order: 2,
    systemId: 24,
    name: "Data Quality",
    menu: {
        "url": "data-quality",
        "icon": "fa fa-certificate",
        "title": "Data Quality",
        "element": undefined,
        "items":[
            {
                "url": "rules",
                "title": "Regras",
                "icon": "fa fa-gavel",
                "element": undefined,
                "items": [
                    {
                        "url": "rules",
                        "title": "Regras",
                        "element": Template,
                        "operationId":1
                    }
                    // {
                    //     "url": "types",
                    //     "title": "Tipos de regras",
                    //     "element": RuleType,
                    //     "operationId":1
                    // },
                    // {
                    //     "url": "categories",
                    //     "title": "Categorias",
                    //     "element": Category,
                    //     "operationId":1
                    // },
                ]
            },
        ]
    }  
}