import { useState } from 'react';
import Tabela from '../../components/Tabela';
import Template from '../../components/Template'
import { IMenu, ISubItem } from '../../interface/entity'

// const  menu = [
//                 Solicitações
//                   [
//                     "Solicitar",
//                     "Em andamento",
//                     "Histórico"
//                   ]
//                 ,

//                   "Diretoria"
//                   [
//                     "Solicitações Pendentes",
//                     "Aprovar Compras"
//                   ]

//               ];

const  menu1 = ["Solicitar","Em andamento","Histórico"];

const pendentes = () => {

  const subitem1: ISubItem[] = 
  [
    {
      Numero: 1,
      Nome: "Solicitar"
    },
    {
      Numero: 2,
      Nome: "Em andamento"
    },
    {
      Numero: 3,
      Nome: "Histórico"
    }
  ]

  const subitem2: ISubItem[] = 
  [
    {
      Numero: 1,
      Nome: "Solicitações Pendentes"
    },
    {
      Numero: 2,
      Nome: "Aprovar Compras"
    }
  ]
    

  const menu: IMenu[] = 
    [
      {
        Numero: 1,
        Nome: "Solicitações",
        SubItem: subitem1
      },
      {
        Numero: 2,
        Nome: "Diretoria",
        SubItem: subitem2
      }
    ]


    const colunas = ["Data", "Número", "Categoria", "Solicitante", "Urgencia"];
    const linhas = ["28/11/2022", 1234, "Limpeza", "Naiara Lima", false];

  return (
    <>
      <Template conteudo={<Tabela colunas={colunas} linhas={linhas}></Tabela>} nome={"Solicitações Pendentes"} menu={menu1}>
      </Template>
    
    </>

  )
}

export default pendentes;
