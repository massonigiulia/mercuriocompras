import { useState } from 'react';
import Template from '../../components/Template'

const  lista = ["Cadastrar usuários","Alterar permissões","bananana"];

const ti = () => {
  return (
      <>
      <Template index={lista.length} lista={lista} nome={"TI"}/>
      </>
    
  )
}

export default ti;
