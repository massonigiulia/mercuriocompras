import Head from 'next/head'
import styles from '../styles/Menu.module.css'
import Image from 'next/image'
import Link from 'next/link'
import { IMenu } from '../interface/entity'


const Tabela = ({ colunas, linhas }) => {
    return (
        <table className={styles.tabela}>
            <thead className={styles.thead}>
                <tr className={styles.tr}>
                    {
                        colunas.map(c => {
                            console.log(c);
                            return (
                                <th className={styles.th}>{c}</th>
                            )

                        })
                    }
                </tr>
            </thead>
            <tbody className={styles.tbody}>
                <tr className={styles.tr}>
                    {
                        linhas.map((l) => {
                            return (
                                <td className={styles.td}>{l}</td>
                            )

                        })
                    }
                </tr>
            </tbody>
        </table>
    )
}
export default Tabela;