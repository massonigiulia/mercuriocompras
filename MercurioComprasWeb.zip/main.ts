// import * as React from "react";
// import * as ReactDOM from "react-dom";

// import Template from "./pages/comp/index";
// import { DefaultApp } from "./core/elements/defaultApp"

// const year = new Date().getFullYear();

// const modules = [Template];

// const defaultApp = React.createElement(DefaultApp {modules, version:"22.8.9.1", year }, []);

// ReactDOM.render(defaultApp, document.getElementById("wrapper"));