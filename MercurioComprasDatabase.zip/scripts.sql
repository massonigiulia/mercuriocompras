-- criação de tabelas (criar na ordem que aparece aqui)

create table Setor(
	codSetor int primary key,
    nomeSetor varchar(60)
);

create table Usuarios(
	codUsuario int auto_increment,
    nome varchar(60),
    login varchar(255),
    email varchar(255),
    senha varchar(50),
    codSetor int,
    nomeSetor varchar(60),
    primary key(codUsuario),
    foreign key (codSetor) references Setor (codSetor),
    unique (login),
    unique (email)
);

create table Categoria(
	codCategoria int primary key,
    nomeCategoria varchar(60)
);

create table Produtos(
	codProduto int primary key,
    nomeProduto varchar(100),
    marca varchar(60),
    codCategoria int,
    foreign key (codCategoria) references Categoria (codCategoria)
);

create table Solicitacao(
	codSolicitacao varchar(5) primary key,
    urgencia boolean,
    dataSolicitacao date,
    codUsuarioRequisitor int,
    codUsuarioDiretor int,
    codCategoria int,
    status int,
    motivoSolicitacao varchar(280),
	motivoRejeicao varchar(280),
    foreign key (codCategoria) references Categoria (codCategoria),
    foreign key (codUsuarioRequisitor) references Usuarios (codUsuario),
    foreign key (codUsuarioDiretor) references Usuarios (codUsuario)
);

create table ItemSolicitacao(
	codSolicitacao varchar(5),
    codProduto int,
    qtde double
);

alter table ItemSolicitacao add constraint foreign key (codProduto) references Produtos (codProduto);
alter table ItemSolicitacao add constraint foreign key (codSolicitacao) references Solicitacao (codSolicitacao);
alter table ItemSolicitacao add constraint codProdSol primary key (codProduto, codSolicitacao);

create table Avaliacao(
	codAvaliacao int primary key,
    notaAtendimento int,
    notaQualidade int,
    notaPreco int,
    notaEntrega int,
    qtdeAvaliacoes int
);

create table Fornecedor(
	codFornecedor int primary key,
    nomeFantasia varchar(60),
    razaoSocial varchar(60),
    cnpj double,
    email varchar(255),
    telefone varchar(50),
    codAvaliacao int,
    foreign key (codAvaliacao) references Avaliacao (codAvaliacao),
    unique (cnpj),
    unique (email)
);

create table CategoriaFornecedor(
	codCategoria int,
    codFornecedor int
);

alter table CategoriaFornecedor add constraint foreign key (codCategoria) references Categoria (codCategoria);
alter table CategoriaFornecedor add constraint foreign key (codFornecedor) references Fornecedor (codFornecedor);
alter table CategoriaFornecedor add constraint codCategoriaFornecedor primary key (codCategoria,codFornecedor);

create table Cotacao(
	codCotacao int primary key,
    dataCotacao date
);

create table CotacaoFornecedor(
	codCategoria int,
    codCotacao int,
    codFornecedor int,
    dataCotacaoFornecedor date,
    status int
);

alter table CotacaoFornecedor add constraint foreign key (codCategoria) references Categoria (codCategoria);
alter table CotacaoFornecedor add constraint foreign key (codCotacao) references Cotacao (codCotacao);
alter table CotacaoFornecedor add constraint foreign key (codFornecedor) references Fornecedor (codFornecedor);
alter table CotacaoFornecedor add constraint codCotacaoFornecedor primary key (codCotacao,codFornecedor);

create table ItemCotacaoFornecedor(
    codCotacao int,
    codFornecedor int,
    codProduto int,
    qtde double,
    precUnit double
);

alter table ItemCotacaoFornecedor add constraint foreign key (codProduto) references Produtos (codProduto);
alter table ItemCotacaoFornecedor add constraint foreign key (codCotacao) references Cotacao (codCotacao);
alter table ItemCotacaoFornecedor add constraint foreign key (codFornecedor) references Fornecedor (codFornecedor);
alter table ItemCotacaoFornecedor add constraint codItemCotacaoFornecedor primary key (codCotacao,codFornecedor);

create table Compras(
	codCompra int primary key,
    codFornecedor int,
    dataCompra date,
    formaPagamento varchar(30),
    codUsuarioDiretor int,
    codUsuarioComprador int,
    status int,
    foreign key (codUsuarioComprador) references Usuarios (codUsuario),
    foreign key (codUsuarioDiretor) references Usuarios (codUsuario)
);

create table ItemCompra(
	codCompra int,
    codProduto int,
    qtde double,
    precUnit double
);

alter table ItemCompra add constraint foreign key (codCompra) references Compras (codCompra);
alter table ItemCompra add constraint foreign key (codProduto) references Produtos (codProduto);
alter table ItemCompra add constraint codItemCompra primary key (codCompra,codProduto);

-- aqui termina a criação de tabelas

-- exemplo de insert em usuário, tá ultrapassado
insert into Usuarios(nome,login,senha,codSetor,nomeSetor) values("Carlos Marques","marquinhos13@gmail.com.br","pdtppuv13",13,"Docente");
insert into Usuarios(nome,login,senha,codSetor,nomeSetor) values("Vladmir Ulianov","lenincionar@gmail.com.br","leningrado",15,"Biblioteca");

-- inserts de categoria
insert into Categoria values(1,"Material Escolar");
insert into Categoria values(2,"Limpeza");
insert into Categoria values(3,"Tecnologia");
insert into Categoria values(4,"Livros");

-- inserts de produtos
insert into Produtos values(1,"Desinfetante 250ml","Veja",2);
insert into Produtos values(2,"Desinfetante 250ml","Pinho Sol",2);
insert into Produtos values(3,"Desinfetante 250ml","Minuano",2);
insert into Produtos values(4,"Lápis de Cor 24 cores","FabberCastell",1);
insert into Produtos values(5,"Lápis de Cor 12 cores","Bic",1);
insert into Produtos values(6,"Teclado LED","Multilaser",3);
insert into Produtos values(7,"Mouse 2500 dpi","Fortrek",3);
insert into Produtos values(8,"Crepúsculo","Intrínseca",4);
insert into Produtos values(9,"Iracema","Atica",4);

-- exemplo de inserção em tabela de solicitação, mas tá ultrapassado
insert into Solicitacao values(codSolicitacao,urgencia,dataSolicitacao,codUsuarioRequisitor,codUsuarioDiretor,codCategoria,status);

-- selects das tabelas existentes
select * from Setor;
select * from Usuarios;
select * from Categoria;
select * from Produtos;
select * from Solicitacao;
select * from ItemSolicitacao;
select * from Avaliacao;
select * from Fornecedor;
select * from CategoriaFornecedor;
select * from Cotacao;
select * from CotacaoFornecedor;
select * from ItemCotacaoFornecedor;
select * from Compras;
select * from ItemCompra;

-- drops das tabelas existentes
drop table ItemCompra;
drop table Compras;
drop table ItemCotacaoFornecedor;
drop table CotacaoFornecedor;
drop table Cotacao;
drop table CategoriaFornecedor;
drop table Fornecedor;
drop table Avaliacao;
drop table ItemSolicitacao;
drop table Solicitacao;
drop table Produtos;
drop table Categoria;
drop table Usuarios;
drop table Setor;

-- joins não lembro do que:

select S.dataSolicitacao, S.codSolicitacao, S.urgencia, C.nomeCategoria, U.nome, P.nomeProduto,
		P.marca, I.qtde from Usuarios U inner join Solicitacao S on
        U.codUsuario = S.codUsuarioRequisitor
        inner join Categoria C on S.codCategoria = C.codCategoria
        inner join Produtos P on C.codCategoria = P.codCategoria
		inner join ItemSolicitacao I on P.codProduto = I.codProduto
        where S.codSolicitacao = 4;
        
select S.dataSolicitacao, S.codSolicitacao, S.urgencia, C.nomeCategoria, U.nome, P.nomeProduto,
		P.marca, I.qtde from Usuarios U inner join Solicitacao S on
        U.codUsuario = S.codUsuarioRequisitor
        inner join Categoria C on S.codCategoria = C.codCategoria
        inner join Produtos P on C.codCategoria = P.codCategoria
		inner join ItemSolicitacao I on P.codProduto = I.codProduto
        where I.codSolicitacao = S.codSolicitacao;

-- esse é o que dá certo de puxar tudo
select S.dataSolicitacao, S.codSolicitacao, S.urgencia, C.nomeCategoria, U.nome, P.nomeProduto,
		P.marca, I.qtde from Usuarios U inner join Solicitacao S on
        U.codUsuario = S.codUsuarioRequisitor
        inner join Categoria C on S.codCategoria = C.codCategoria
        inner join Produtos P on C.codCategoria = P.codCategoria
		inner join ItemSolicitacao I on P.codProduto = I.codProduto;
        

-- exibir lista de solicitações

select S.dataSolicitacao, S.codSolicitacao, S.urgencia, S.status, C.nomeCategoria, U.nome
		from Usuarios U inner join Solicitacao S on
        U.codUsuario = S.codUsuarioRequisitor
        inner join Categoria C on S.codCategoria = C.codCategoria
        where S.status = 0;
       
       
-- exibir lista de itens de uma solicitação
        
select S.dataSolicitacao, S.codSolicitacao, S.urgencia, C.nomeCategoria, U.nome, P.nomeProduto,
		P.marca, I.qtde from Usuarios U inner join Solicitacao S on
        U.codUsuario = S.codUsuarioRequisitor
        inner join Categoria C on S.codCategoria = C.codCategoria
        inner join Produtos P on C.codCategoria = P.codCategoria
		inner join ItemSolicitacao I on P.codProduto = I.codProduto;

select S.dataSolicitacao, S.codSolicitacao, S.urgencia, S.status, C.nomeCategoria, U.nome, P.nomeProduto,
		P.marca, I.qtde from Usuarios U inner join Solicitacao S on
        U.codUsuario = S.codUsuarioRequisitor
        inner join Categoria C on S.codCategoria = C.codCategoria
        inner join Produtos P on C.codCategoria = P.codCategoria
		inner join ItemSolicitacao I on P.codProduto = I.codProduto
        where S.codSolicitacao = 1;