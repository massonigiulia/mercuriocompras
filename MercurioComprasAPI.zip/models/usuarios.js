const conexao = require("../infraestrutura/conexao")

class Usuario {
    lista(res,req) {
        const query = `select * from Usuarios`
        conexao.query(query,(erro, resultados) => {
            if(erro) {
                res.status(400).json(erro)
            } else {
                res.status(200).json(resultados)
            }
        })
    }

    atualizar(res,codUsuario,valores) {
        const query = `update Usuarios set ? where codUsuario=?`
        console.log(valores)
        conexao.query(query,[valores,codUsuario],(erro, resultados) => {
            if(erro) {
                res.status(400).json(erro)
            } else {
                res.status(200).json({...valores, codUsuario})
            }
        })
    }

    login(res,login,senha) {
        const query = `select login, senha from Usuarios where login=? and senha=?`
        conexao.query(query,[login,senha],(erro, resultados) => {
            if(erro) {
                res.status(400).json(erro)
            } else {

                
                
                res.status(200).json(resultados)
            }
        })
    }

    cadastrar(res,valores) {

        //cadastro de vários usuarios de uma vez
        // valores.map((valor) => {
        //     const query = `insert into Usuarios set ?`
        //     conexao.query(query,valor,(erro, resultados) => {
        //         if(erro) {
        //             res.status(400).json(erro)
        //         } else {
        //         }
        //     })
        // })
        // res.status(200).json({...valores})

    
        const query = `insert into Usuarios set ?`
        conexao.query(query,valores,(erro, resultados) => {
            if(erro) {
                res.status(400).json(erro)
            } else {
            }
            res.status(200).json({...valores})
        })
    
    }

    excluir(res,codUsuario) {
        const query = `delete from Usuarios where codUsuario=?`
        console.log(codUsuario)
        conexao.query(query,codUsuario,(erro, resultados) => {
            if(erro) {
                res.status(400).json(erro)
            } else {
                res.status(200).json({status:`Usuário ${codUsuario} excluído`})
            }
        })
    }

    listaOrder(res,req,order,column) {
        const query = `select * from Usuarios order by ${column} ${order}`
        conexao.query(query,(erro, resultados) => {
            if(erro) {
                res.status(400).json(erro)
            } else {
                res.status(200).json(resultados)
            }
        })
    }
}

module.exports = new Usuario