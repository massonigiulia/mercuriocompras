const conexao = require("../infraestrutura/conexao")
const moment = require("moment")

class Solicitacao {

    //diretor
    exibirListaSolicitacoesPendentes(res,req) {

        const query = `select S.dataSolicitacao, S.codSolicitacao, S.urgencia, C.nomeCategoria, U.nome
                        from Usuarios U inner join Solicitacao S on U.codUsuario = S.codUsuarioRequisitor
                        inner join Categoria C on S.codCategoria = C.codCategoria
                        where S.status = 0`
        conexao.query(query,(erro, resultados) => {
            if(erro) {
                res.status(400).json(erro)
            } else {
                res.status(200).json(resultados)
            }
        })
    }

    //diretor
    exibirSolicitacaoPendente(res,codSolicitacao) {

        const query = `select S.dataSolicitacao, S.codSolicitacao, S.urgencia, S.status, C.nomeCategoria,
                        U.nome, P.nomeProduto, P.marca, I.qtde from Usuarios U
                        inner join Solicitacao S on U.codUsuario = S.codUsuarioRequisitor
                        inner join Categoria C on S.codCategoria = C.codCategoria
                        inner join Produtos P on C.codCategoria = P.codCategoria
                        inner join ItemSolicitacao I on P.codProduto = I.codProduto
                        where S.codSolicitacao = ?`
        conexao.query(query,codSolicitacao,(erro, resultados) => {
            if(erro) {
                res.status(400).json(erro)
            } else {
                res.status(200).json(resultados)
            }
        })
    }

    //requisitor
    cadastrarSolicitacao(res,valores) {

        const id = Math.floor(Math.random() * 0x10000)

        const query1 = `insert into Solicitacao (codSolicitacao,urgencia,dataSolicitacao,codUsuarioRequisitor,codUsuarioDiretor,codCategoria,status) values ('${id}',${valores.urgencia},'${moment(valores.dataSolicitacao).format("YYYY-MM-DD")}',${valores.codUsuarioRequisitor},${8},${valores.codCategoria},${0})`

        conexao.query(query1,(erro, resultados) => {
            if(erro) {
                res.status(400).json(erro)
            } else {
                valores.itens.map((item) => {
                    const query2 = `insert into ItemSolicitacao values ('${id}',${item.id}, ${item.qtde})`

                    conexao.query(query2, (erro,resultado) => {
                        if(erro){
                            res.status(400).json(erro)
                        }else{
                            // res.status(200).json(resultado)
                        }
                    })
        
                })
            }
            res.status(200).json(resultados)
        })

    }

}


module.exports = new Solicitacao