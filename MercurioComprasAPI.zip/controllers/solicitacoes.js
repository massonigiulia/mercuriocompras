const Solicitacoes = require("../models/solicitacoes")

module.exports = (app) => {

    app.get("/diretor/solicitacoes_pendentes",(req,res) => {
        Solicitacoes.exibirListaSolicitacoesPendentes(res,req)
    })

    app.get("/diretor/solicitacoes_pendentes/:codSolicitacao",(req,res) => {
        const codSolicitacao = req.params.codSolicitacao
        Solicitacoes.exibirSolicitacaoPendente(res,codSolicitacao)
    })
    
    app.post("/solicitar",(req,res) => {
        valores = req.body
        Solicitacoes.cadastrarSolicitacao(res,valores)
    })

}