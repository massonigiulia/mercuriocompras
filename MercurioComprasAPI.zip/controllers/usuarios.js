const Usuario = require("../models/usuarios")

module.exports = (app) => {
    app.get("/usuarios",(req,res) => {
        Usuario.lista(res,req)
    })
    
    app.get("/usuarios/order/:column/:order",(req,res) => {
        const {order,column} = req.params
        Usuario.listaOrder(res,req,order,column)
        // console.log(order)
        // console.log(column)
    })

    app.patch("/usuarios/:codUsuario",(req,res) => {
        const {codUsuario} = req.params
        const valores = req.body
        Usuario.atualizar(res,codUsuario,valores)    
    })

    app.post("/usuarios",(req,res) => {
        const valores = req.body
        Usuario.cadastrar(res,valores)    
    })

    app.post("/usuarios/login",(req,res) => {
        const {login,senha} = req.body
        Usuario.login(res,login,senha)    
    })

    app.delete("/usuarios/:codUsuario",(req,res) => {
        const {codUsuario} = req.params
        Usuario.excluir(res,codUsuario)    
    })

}